import { getVoiceWebSocketUrl } from '@/lib/api'

export type AgentFrontendState = {
  content_type?: 'movie' | 'series'
  content_id?: string
  content_title?: string
  is_playing?: boolean
  current_time_seconds?: number
  page?: string
}

export type AgentMessage = {
  type?: string
  action?: string
  message?: string
  payload?: {
    action?: string
    tool?: string
    params?: Record<string, unknown>
    message?: string
    text?: string
    state?: string
    requires_confirmation?: boolean
  }
}

type AgentSocketHandlers = {
  onOpen?: () => void
  onMessage?: (message: AgentMessage) => void
  onClose?: (event: CloseEvent) => void
  onError?: () => void
}

export type AgentSocketHandle = {
  send: (text: string, state?: AgentFrontendState) => void
  close: () => void
  readyState: () => number
}

// Opens a websocket connection to the AI agent ONLY when explicitly called.
// The caller (VoiceAssistantProvider) is responsible for calling close() when
// the assistant is toggled off — there is no auto-reconnect by design.
export function connectAgentSocket(token: string, handlers: AgentSocketHandlers): AgentSocketHandle | null {
  if (typeof window === 'undefined') return null
  const sessionId = `web_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`
  const wsUrl = getVoiceWebSocketUrl(sessionId)
  let url: URL
  try {
    url = new URL(wsUrl)
  } catch {
    handlers.onError?.()
    return null
  }
  url.searchParams.set('token', token)

  let socket: WebSocket
  try {
    socket = new WebSocket(url.toString())
  } catch {
    handlers.onError?.()
    return null
  }

  socket.onopen = () => handlers.onOpen?.()
  socket.onmessage = event => {
    try {
      const data = JSON.parse(event.data) as AgentMessage
      handlers.onMessage?.(data)
    } catch {
      /* ignore malformed frame */
    }
  }
  socket.onerror = () => handlers.onError?.()
  socket.onclose = event => handlers.onClose?.(event)

  return {
    send: (text, state) => {
      if (socket.readyState !== WebSocket.OPEN) return
      socket.send(JSON.stringify({ text, frontend_state: state }))
    },
    close: () => {
      try {
        socket.close()
      } catch {
        /* ignore */
      }
    },
    readyState: () => socket.readyState,
  }
}
