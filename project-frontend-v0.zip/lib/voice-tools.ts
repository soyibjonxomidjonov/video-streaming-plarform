// Bridge that lets the currently mounted <video> / watch page expose real
// player + content actions to the global voice assistant. Registered by
// WatchClient while mounted, cleared on unmount.
export type PlayerBridge = {
  videoRef: React.RefObject<HTMLVideoElement | null>
  contentType: 'movie' | 'series'
  contentId: string
  contentTitle: string
  hasNextEpisode: () => boolean
  hasPreviousEpisode: () => boolean
  nextEpisode: () => void
  previousEpisode: () => void
  toggleFavorite: () => void
  rate: (value: number) => void
  addComment: (text: string) => Promise<void> | void
}

// Backend tool names that map to a real, already-wired API action. Anything
// not listed here must not be executed client-side — it stays with the
// backend agent's own tool execution.
export const DESTRUCTIVE_TOOLS = new Set(['logout', 'remove_favorite', 'delete_comment', 'clear_history'])

export type VoiceToolResult = { ok: boolean; message?: string }
