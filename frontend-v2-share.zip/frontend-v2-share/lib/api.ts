const DEFAULT_API_URL = 'https://backend.scholarmap.uz'
const DEFAULT_STREAMER_HEALTH_URL = 'https://backend.scholarmap.uz/health'

function normalizeBaseUrl(value: string) {
  return value.replace(/\/+$/, '')
}

export const API_BASE = normalizeBaseUrl(process.env.NEXT_PUBLIC_API_URL?.trim() || DEFAULT_API_URL)
export const STREAMER_HEALTH = normalizeBaseUrl(process.env.NEXT_PUBLIC_STREAMER_HEALTH?.trim() || DEFAULT_STREAMER_HEALTH_URL)

const REQUEST_BASE = API_BASE

export function getGoogleAuthUrl() {
  return process.env.NEXT_PUBLIC_GOOGLE_AUTH_URL?.trim() || `${API_BASE}/v1/auth/google/`
}

export function getVoiceWebSocketUrl(sessionId = 'web') {
  const configured = process.env.NEXT_PUBLIC_VOICE_WS_URL?.trim()
  if (configured) return configured.replace('{session_id}', encodeURIComponent(sessionId))
  const url = new URL(API_BASE)
  url.protocol = url.protocol === 'https:' ? 'wss:' : 'ws:'
  url.pathname = `/ws/agent/${encodeURIComponent(sessionId)}/`
  url.search = ''
  return url.toString()
}

export type Genre = { id: number; name: string }

export type MediaItem = {
  id: number
  title?: string
  name?: string
  description?: string
  overview?: string
  poster?: string
  poster_url?: string
  poster_image?: string
  image?: string
  backdrop?: string
  backdrop_url?: string
  backdrop_image?: string
  year?: number | string
  release_year?: number | string
  rating?: number | string
  average_rating?: number | string
  duration?: number | string
  duration_seconds?: number
  genre?: string | Genre[]
  genres?: Genre[]
  episodes?: Episode[]
  seasons?: Season[]
  is_cashed?: boolean
  telegram_channel?: string
  created_at?: string
  type?: 'movie' | 'series'
}

export type Episode = {
  id: number
  title?: string
  name?: string
  episode_number?: number
  season_number?: number
  duration?: number | string
  duration_seconds?: number
  poster?: string
  poster_url?: string
  series?: number | { id: number; title?: string }
  created_at?: string
}

export type Season = {
  id: number
  season_number?: number
  name?: string
  episodes?: Episode[]
}

export type Comment = {
  id: number
  text?: string
  content?: string
  user?: number | string | { id?: number; username?: string; email?: string; first_name?: string; last_name?: string }
  username?: string
  movie?: number
  series?: number
  created_at?: string
}

export type Rating = {
  id: number
  stars: number
  user?: number | { id: number; email?: string }
  movie?: number
  series?: number
  updated_at?: string
}

export type WatchProgress = {
  id: number
  movie?: MediaItem | number
  episode?: (Episode & { series?: MediaItem }) | number
  position_seconds: number
  updated_at?: string
}

export type FavoriteItem = {
  id: number
  movie?: MediaItem | number
  series?: MediaItem | number
  created_at?: string
}

export type UserProfile = {
  id?: number
  email?: string
  username?: string
  first_name?: string
  last_name?: string
  age?: number | string
  is_staff?: boolean
  is_superuser?: boolean
  role?: string
  date_joined?: string
}

export type SearchResult = {
  id: number
  title: string
  description: string
  distance: number
  content_type: 'movie' | 'series'
  object_id: number
}

export type ApiList<T> = T[] | { results: T[]; count?: number; next?: string | null; previous?: string | null }

export class ApiError extends Error {
  status: number
  constructor(message: string, status: number) {
    super(message)
    this.status = status
  }
}

const TOKEN_KEY = 'streamora_token'
const REFRESH_KEY = 'streamora_refresh'

export function getToken(): string | null {
  if (typeof window === 'undefined') return null
  try { return window.localStorage.getItem(TOKEN_KEY) } catch { return null }
}

export function setToken(token: string | null) {
  if (typeof window === 'undefined') return
  try {
    if (token) window.localStorage.setItem(TOKEN_KEY, token)
    else window.localStorage.removeItem(TOKEN_KEY)
  } catch { /* ignore */ }
}

export function getRefreshToken(): string | null {
  if (typeof window === 'undefined') return null
  try { return window.localStorage.getItem(REFRESH_KEY) } catch { return null }
}

export function setRefreshToken(token: string | null) {
  if (typeof window === 'undefined') return
  try {
    if (token) window.localStorage.setItem(REFRESH_KEY, token)
    else window.localStorage.removeItem(REFRESH_KEY)
  } catch { /* ignore */ }
}

export function unwrapList<T>(data: ApiList<T> | undefined | null): T[] {
  if (!data) return []
  if (Array.isArray(data)) return data
  if (Array.isArray(data.results)) return data.results
  return []
}

export function mediaTitle(item: MediaItem | Episode | null | undefined): string {
  if (!item) return 'Nomsiz'
  return item.title ?? item.name ?? 'Nomsiz'
}

export function mediaDescription(item: MediaItem | null | undefined): string {
  if (!item) return ''
  return item.description ?? item.overview ?? ''
}

export function mediaImage(item: MediaItem | Episode | null | undefined, kind: 'poster' | 'backdrop' = 'poster'): string {
  if (!item) return ''
  const m = item as MediaItem
  const poster = m.poster_url ?? m.poster ?? m.poster_image ?? m.image ?? ''
  const backdrop = m.backdrop_url ?? m.backdrop ?? m.backdrop_image ?? ''
  return kind === 'backdrop' ? backdrop || poster : poster || backdrop
}

export function mediaRating(item: MediaItem | null | undefined): number | null {
  if (!item) return null
  const value = item.rating ?? item.average_rating
  const num = typeof value === 'string' ? Number.parseFloat(value) : value
  return typeof num === 'number' && !Number.isNaN(num) ? num : null
}

export function mediaYear(item: MediaItem | null | undefined): string | number | null {
  if (!item) return null
  if (item.year) return item.year
  if (item.release_year) return item.release_year
  if (item.created_at) {
    try {
      return new Date(item.created_at).getFullYear()
    } catch {
      return null
    }
  }
  return null
}

function buildApiPath(basePath: string, paramsStr?: string): string {
  const cleanBase = basePath.endsWith('/') ? basePath : `${basePath}/`
  if (!paramsStr) return cleanBase
  const cleanParams = paramsStr.replace(/^\?/, '')
  return cleanParams ? `${cleanBase}?${cleanParams}` : cleanBase
}

let isRefreshing = false
let refreshPromise: Promise<string | null> | null = null

async function performTokenRefresh(): Promise<string | null> {
  const refreshToken = getRefreshToken()
  if (!refreshToken) return null

  if (isRefreshing && refreshPromise) {
    return refreshPromise
  }

  isRefreshing = true
  refreshPromise = (async () => {
    try {
      const res = await fetch(`${REQUEST_BASE}/v1/auth/token/refresh/`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refresh: refreshToken }),
      })
      if (res.ok) {
        const data = await res.json()
        if (data?.access) {
          setToken(data.access)
          return data.access
        }
      }
      return null
    } catch {
      return null
    } finally {
      isRefreshing = false
      refreshPromise = null
    }
  })()

  return refreshPromise
}

// 3.5s timeout prevents blocking any route
async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), 3500)
  const token = getToken()
  const isGet = !init?.method || init.method === 'GET'

  try {
    const response = await fetch(`${REQUEST_BASE}${path}`, {
      ...init,
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        ...(init?.headers ?? {}),
      },
      credentials: 'include',
      cache: isGet && !token ? 'no-cache' : 'no-store',
      signal: controller.signal,
    })

    if (response.status === 401 && !path.includes('/auth/')) {
      const newAccess = await performTokenRefresh()
      if (newAccess) {
        return request<T>(path, {
          ...init,
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${newAccess}`,
            ...(init?.headers ?? {}),
          },
        })
      }
    }

    if (!response.ok) {
      let detail = `API xatoligi: ${response.status}`
      try {
        const body = await response.json()
        detail = body.detail ?? body.message ?? detail
      } catch { /* non-json */ }
      throw new ApiError(detail, response.status)
    }

    if (response.status === 204) return undefined as T
    const text = await response.text()
    return (text ? JSON.parse(text) : undefined) as T
  } finally {
    clearTimeout(timeout)
  }
}

export const api = {
  // === KONTENT (Asinxron va Xavfsiz) ===
  movies: async (params = ''): Promise<ApiList<MediaItem>> => {
    try {
      return await request<ApiList<MediaItem>>(buildApiPath('/v1/movie', params))
    } catch {
      return { results: [], count: 0 }
    }
  },
  movie: (id: string | number) => request<MediaItem>(`/v1/movie/${id}/`),
  createMovie: (data: Partial<MediaItem>) => request<MediaItem>('/v1/movie/', { method: 'POST', body: JSON.stringify(data) }),
  updateMovie: (id: string | number, data: Partial<MediaItem>) => request<MediaItem>(`/v1/movie/${id}/`, { method: 'PATCH', body: JSON.stringify(data) }),
  deleteMovie: (id: string | number) => request<void>(`/v1/movie/${id}/`, { method: 'DELETE' }),

  series: async (params = ''): Promise<ApiList<MediaItem>> => {
    try {
      return await request<ApiList<MediaItem>>(buildApiPath('/v1/series', params))
    } catch {
      return { results: [], count: 0 }
    }
  },
  serie: (id: string | number) => request<MediaItem>(`/v1/series/${id}/`),
  createSeries: (data: Partial<MediaItem>) => request<MediaItem>('/v1/series/', { method: 'POST', body: JSON.stringify(data) }),
  updateSeries: (id: string | number, data: Partial<MediaItem>) => request<MediaItem>(`/v1/series/${id}/`, { method: 'PATCH', body: JSON.stringify(data) }),
  deleteSeries: (id: string | number) => request<void>(`/v1/series/${id}/`, { method: 'DELETE' }),

  episodes: async (params = ''): Promise<ApiList<Episode>> => {
    try {
      return await request<ApiList<Episode>>(buildApiPath('/v1/episode', params))
    } catch {
      return { results: [], count: 0 }
    }
  },
  episode: (id: string | number) => request<Episode>(`/v1/episode/${id}/`),
  seriesEpisodes: async (seriesId: string | number): Promise<ApiList<Episode>> => {
    try {
      return await request<ApiList<Episode>>(buildApiPath('/v1/episode', `series=${seriesId}`))
    } catch {
      return { results: [], count: 0 }
    }
  },
  createEpisode: (data: Partial<Episode>) => request<Episode>('/v1/episode/', { method: 'POST', body: JSON.stringify(data) }),
  updateEpisode: (id: string | number, data: Partial<Episode>) => request<Episode>(`/v1/episode/${id}/`, { method: 'PATCH', body: JSON.stringify(data) }),
  deleteEpisode: (id: string | number) => request<void>(`/v1/episode/${id}/`, { method: 'DELETE' }),

  genres: async (params = ''): Promise<ApiList<Genre>> => {
    try {
      return await request<ApiList<Genre>>(buildApiPath('/v1/genre', params))
    } catch {
      return { results: [], count: 0 }
    }
  },
  genre: (id: string | number) => request<Genre>(`/v1/genre/${id}/`),
  createGenre: (data: { name: string }) => request<Genre>('/v1/genre/', { method: 'POST', body: JSON.stringify(data) }),
  updateGenre: (id: string | number, data: { name: string }) => request<Genre>(`/v1/genre/${id}/`, { method: 'PATCH', body: JSON.stringify(data) }),
  deleteGenre: (id: string | number) => request<void>(`/v1/genre/${id}/`, { method: 'DELETE' }),

  // === QIDIRUV (Semantik + DRF Keyword) ===
  search: async (query: string, limit = 20): Promise<ApiList<SearchResult>> => {
    try {
      return await request<ApiList<SearchResult>>(
        `/v1/embedding_search/search/?q=${encodeURIComponent(query)}&limit=${limit}`
      )
    } catch {
      return { results: [], count: 0 }
    }
  },
  searchMovies: async (query: string): Promise<ApiList<MediaItem>> => {
    try {
      return await request<ApiList<MediaItem>>(buildApiPath('/v1/movie', `search=${encodeURIComponent(query)}`))
    } catch {
      return { results: [], count: 0 }
    }
  },
  searchSeries: async (query: string): Promise<ApiList<MediaItem>> => {
    try {
      return await request<ApiList<MediaItem>>(buildApiPath('/v1/series', `search=${encodeURIComponent(query)}`))
    } catch {
      return { results: [], count: 0 }
    }
  },

  // === STREAM URL (Go Streamer 302) ===
  movieStream: (id: string | number) => `${API_BASE}/v1/movie/${id}/stream/`,
  episodeStream: (id: string | number) => `${API_BASE}/v1/episode/${id}/stream/`,

  // === AUTH & PROFIL ===
  user: async (id: number | string) => {
    if (!getToken()) return null
    try {
      return await request<UserProfile>(`/v1/users/${id}/`)
    } catch {
      return null
    }
  },
  users: async (params = ''): Promise<ApiList<UserProfile>> => {
    try {
      return await request<ApiList<UserProfile>>(buildApiPath('/v1/users', params))
    } catch {
      return { results: [], count: 0 }
    }
  },
  updateUser: (id: number | string, data: Partial<UserProfile>) =>
    request<UserProfile>(`/v1/users/${id}/`, { method: 'PATCH', body: JSON.stringify(data) }),
  login: (email: string) =>
    request<{ message: string }>('/v1/auth/login/', { method: 'POST', body: JSON.stringify({ email }) }),
  register: (payload: { email: string; first_name?: string; last_name?: string; age?: string | number }) =>
    request<{ message: string }>('/v1/auth/register/', { method: 'POST', body: JSON.stringify(payload) }),
  verifyCode: (email: string, code: string) =>
    request<{ access: string; refresh: string }>('/v1/auth/code/verify/', {
      method: 'POST',
      body: JSON.stringify({ email, verify_code: code }),
    }),
  refreshToken: (refresh: string) =>
    request<{ access: string }>('/v1/auth/token/refresh/', {
      method: 'POST',
      body: JSON.stringify({ refresh }),
    }),
  googleLogin: (idToken: string) =>
    request<{ access: string; refresh: string }>('/v1/auth/google/login/', {
      method: 'POST',
      body: JSON.stringify({ id_token: idToken }),
    }),

  // === FOYDALANUVCHI AMALLARI ===
  movieComments: async (movieId: number | string): Promise<ApiList<Comment>> => {
    try {
      return await request<ApiList<Comment>>(buildApiPath('/v1/movie-comments', `movie=${movieId}`))
    } catch {
      return { results: [], count: 0 }
    }
  },
  seriesComments: async (seriesId: number | string): Promise<ApiList<Comment>> => {
    try {
      return await request<ApiList<Comment>>(buildApiPath('/v1/series-comments', `series=${seriesId}`))
    } catch {
      return { results: [], count: 0 }
    }
  },
  addMovieComment: (movieId: number | string, text: string) =>
    request<Comment>('/v1/movie-comments/', { method: 'POST', body: JSON.stringify({ movie: Number(movieId), text }) }),
  addSeriesComment: (seriesId: number | string, text: string) =>
    request<Comment>('/v1/series-comments/', { method: 'POST', body: JSON.stringify({ series: Number(seriesId), text }) }),
  deleteMovieComment: (id: number | string) => request<void>(`/v1/movie-comments/${id}/`, { method: 'DELETE' }),
  deleteSeriesComment: (id: number | string) => request<void>(`/v1/series-comments/${id}/`, { method: 'DELETE' }),

  movieRating: async (movieId: number | string): Promise<ApiList<Rating>> => {
    try {
      return await request<ApiList<Rating>>(buildApiPath('/v1/movie-rating', `movie=${movieId}`))
    } catch {
      return { results: [], count: 0 }
    }
  },
  seriesRating: async (seriesId: number | string): Promise<ApiList<Rating>> => {
    try {
      return await request<ApiList<Rating>>(buildApiPath('/v1/series-rating', `series=${seriesId}`))
    } catch {
      return { results: [], count: 0 }
    }
  },
  rateMovie: (movieId: number | string, stars: number) =>
    request<Rating>('/v1/movie-rating/', { method: 'POST', body: JSON.stringify({ movie: Number(movieId), stars }) }),
  rateSeries: (seriesId: number | string, stars: number) =>
    request<Rating>('/v1/series-rating/', { method: 'POST', body: JSON.stringify({ series: Number(seriesId), stars }) }),

  favoritesMovie: async (): Promise<ApiList<FavoriteItem>> => {
    if (!getToken()) return { results: [], count: 0 }
    try {
      return await request<ApiList<FavoriteItem>>('/v1/movie-favourite/')
    } catch {
      return { results: [], count: 0 }
    }
  },
  favoritesSeries: async (): Promise<ApiList<FavoriteItem>> => {
    if (!getToken()) return { results: [], count: 0 }
    try {
      return await request<ApiList<FavoriteItem>>('/v1/series-favourite/')
    } catch {
      return { results: [], count: 0 }
    }
  },
  addFavoriteMovie: (movieId: number | string) =>
    request<FavoriteItem>('/v1/movie-favourite/', { method: 'POST', body: JSON.stringify({ movie: Number(movieId) }) }),
  addFavoriteSeries: (seriesId: number | string) =>
    request<FavoriteItem>('/v1/series-favourite/', { method: 'POST', body: JSON.stringify({ series: Number(seriesId) }) }),
  removeFavoriteMovie: async (id: number | string) => {
    if (!getToken()) return undefined
    try {
      return await request<void>(`/v1/movie-favourite/${id}/`, { method: 'DELETE' })
    } catch {
      return undefined
    }
  },
  removeFavoriteSeries: async (id: number | string) => {
    if (!getToken()) return undefined
    try {
      return await request<void>(`/v1/series-favourite/${id}/`, { method: 'DELETE' })
    } catch {
      return undefined
    }
  },

  historyMovie: async (): Promise<ApiList<WatchProgress>> => {
    if (!getToken()) return { results: [], count: 0 }
    try {
      return await request<ApiList<WatchProgress>>('/v1/movie-watchprogress/')
    } catch {
      return { results: [], count: 0 }
    }
  },
  historySeries: async (): Promise<ApiList<WatchProgress>> => {
    if (!getToken()) return { results: [], count: 0 }
    try {
      return await request<ApiList<WatchProgress>>('/v1/series-watchprogress/')
    } catch {
      return { results: [], count: 0 }
    }
  },
  progressMovie: async (movieId: number | string, positionSeconds: number) => {
    if (!getToken()) return undefined
    try {
      return await request<WatchProgress>('/v1/movie-watchprogress/', {
        method: 'POST',
        body: JSON.stringify({ movie: Number(movieId), position_seconds: Math.round(positionSeconds) }),
      })
    } catch {
      return undefined
    }
  },
  progressSeries: async (episodeId: number | string, positionSeconds: number) => {
    if (!getToken()) return undefined
    try {
      return await request<WatchProgress>('/v1/series-watchprogress/', {
        method: 'POST',
        body: JSON.stringify({ episode: Number(episodeId), position_seconds: Math.round(positionSeconds) }),
      })
    } catch {
      return undefined
    }
  },
  clearMovieHistory: (id: number | string) => request<void>(`/v1/movie-watchprogress/${id}/`, { method: 'DELETE' }),
  clearSeriesHistory: (id: number | string) => request<void>(`/v1/series-watchprogress/${id}/`, { method: 'DELETE' }),
}
