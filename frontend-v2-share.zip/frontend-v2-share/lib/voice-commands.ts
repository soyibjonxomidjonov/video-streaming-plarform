// Local (client-side) fast-path matcher for multilingual voice commands (Layer 0).
// Handles zero-latency DOM operations for player controls, volume, navigation,
// and scrolling directly on document.querySelector('[data-role="main-player"]').

export type LocalCommand = {
  action: string
  params?: {
    seconds?: number
    value?: number
    speed?: number
    query?: string
    target?: string
  }
}

export function normalizeUzbekSTT(raw: string): string {
  return raw
    .toLowerCase()
    .replace(/[’ʻʼ`´]/g, "'")
    .replace(/[.,!?;:]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
}

function hasAny(text: string, words: string[]): boolean {
  return words.some((word) => text.includes(word))
}

function isNegated(text: string, stems: string[]): boolean {
  return stems.some((stem) => text.includes(`${stem}ma`) || text.includes(`${stem}mang`) || text.includes(`${stem}masin`))
}

function firstNumber(text: string): number | null {
  const match = text.match(/(\d+(?:[.,]\d+)?)/)
  if (!match) return null
  return Number.parseFloat(match[1].replace(',', '.'))
}

export function matchLocalCommand(transcriptRaw: string): LocalCommand | null {
  const text = normalizeUzbekSTT(transcriptRaw)
  if (!text) return null

  // 1. Search: "qidir [query]" | "search [query]" | "найти [query]"
  const searchMatch = text.match(/(?:qidir|search|найти|izla)\s+(.+)/)
  if (searchMatch) {
    return { action: 'search', params: { query: searchMatch[1].trim() } }
  }

  // 2. Assistant control
  if (hasAny(text, ["yordamchini o'chir", "ovozli boshqaruvni o'chir", "mikrofonni o'chir", "tinglashni to'xtat", "stop listening", "yop yordamchini", "выключить микрофон"])) {
    return { action: 'stop_listening' }
  }

  // 3. Play / Pause
  const pauseStems = ["to'xtat", 'pauza', 'stop', 'стоп']
  if (!isNegated(text, pauseStems) && hasAny(text, ['pauza', "to'xtat", 'toxtat', 'kutib tur', 'pause', 'стоп'])) {
    if (!hasAny(text, ['orqaga', 'soniya', 'daqiqa', 'sekund', 'назад'])) {
      return { action: 'pause_video' }
    }
  }

  const playStems = ["o'ynat", 'boshla', 'davom', 'play', 'играть']
  if (!isNegated(text, playStems) && hasAny(text, ["o'ynat", 'oynat', 'ijro et', 'davom et', 'davom ettir', 'boshla', 'play', 'играть', 'pleer'])) {
    return { action: 'play_video' }
  }

  // 4. Restart video / episode
  if (hasAny(text, ["boshidan qo'y", "boshidan boshla", "qaytadan boshla", "restart", "boshiga qayt", "заново", "сначала"])) {
    return { action: 'restart_video' }
  }

  // 5. Seek forward / backward
  if (hasAny(text, ['oldinga', 'oldiga', 'ilgari', 'forward', "o'tkaz", 'вперед'])) {
    const rawNum = firstNumber(text)
    const seconds = hasAny(text, ['daqiqa', 'minut', 'minute', 'минут']) ? (rawNum ?? 1) * 60 : (rawNum ?? 10)
    return { action: 'seek_forward', params: { seconds } }
  }

  if (hasAny(text, ['orqaga', 'ortga', 'backward', 'qaytar', 'rewind', 'назад']) && hasAny(text, ['soniya', 'sekund', 'daqiqa', 'minut', 'minute', 'sek', 'qadam', 'секунд', 'минут'])) {
    const rawNum = firstNumber(text)
    const seconds = hasAny(text, ['daqiqa', 'minut', 'minute', 'минут']) ? (rawNum ?? 1) * 60 : (rawNum ?? 10)
    return { action: 'seek_backward', params: { seconds } }
  }

  if (text === 'orqaga' || hasAny(text, ['bir oz orqaga', 'ozgina orqaga', 'biroz ortga'])) {
    return { action: 'seek_backward', params: { seconds: 10 } }
  }

  // 6. Absolute seek
  const timeMatch = text.match(/(\d+)\s*:\s*(\d+)/)
  if (timeMatch && hasAny(text, ["o't", 'otish', "o'tkaz", 'bor'])) {
    const seconds = Number.parseInt(timeMatch[1], 10) * 60 + Number.parseInt(timeMatch[2], 10)
    return { action: 'seek_to_time', params: { seconds } }
  }
  if (hasAny(text, ['daqiqaga', 'daqiqasiga', 'minutga']) && hasAny(text, ["o't", "o'tkaz", 'bor'])) {
    const minutes = firstNumber(text) ?? 0
    return { action: 'seek_to_time', params: { seconds: minutes * 60 } }
  }

  // 7. Volume Control
  if (hasAny(text, ["ovozni o'chir", 'ovozni ochir', 'jim qil', 'ovozsiz', 'mute', 'без звука'])) {
    return { action: 'mute' }
  }
  if (hasAny(text, ['ovozni yoq', 'ovozni och', 'unmute', 'ovoz qayt', 'включить звук']) && !hasAny(text, ['past', 'baland', 'kotar'])) {
    return { action: 'unmute' }
  }

  const volumeMatch = text.match(/ovoz\w*\s*(\d+)\s*(foiz|%|percent)?/)
  if (volumeMatch) {
    const value = Number.parseInt(volumeMatch[1], 10)
    return { action: 'set_volume', params: { value: Math.max(0, Math.min(100, value)) } }
  }

  if (hasAny(text, ['ovozni baland', "ovozni ko'tar", 'ovozni oshir', 'balandroq', 'qattiqroq', 'volume up', 'ovozni balandlat', 'громче', 'увеличить звук'])) {
    return { action: 'increase_volume' }
  }
  if (hasAny(text, ['ovozni past', 'ovozni tushir', 'ovozni kamaytir', 'pastroq', 'sekinroq ovoz', 'volume down', 'ovozni pasaytir', 'тише', 'уменьшить звук'])) {
    return { action: 'decrease_volume' }
  }

  // 8. Fullscreen & PiP & Theater
  if (hasAny(text, ["to'liq ekran", 'toliq ekran', 'butun ekran', 'katta ekran', 'fullscreen', 'kattalashtir', 'полный экран', 'во весь экран'])) {
    return { action: 'enter_fullscreen' }
  }
  if (hasAny(text, ['ekrandan chiq', 'kichraytir', 'kichik ekran', 'exit fullscreen', 'normallashtir', 'выйти из полного экрана'])) {
    return { action: 'exit_fullscreen' }
  }
  if (hasAny(text, ['kichik oyna', 'pip', 'picture in picture', 'oynada ko\'rsat'])) {
    return { action: 'toggle_picture_in_picture' }
  }
  if (hasAny(text, ['teatr rejimi', 'theater mode', 'kino zali'])) {
    return { action: 'toggle_theater_mode' }
  }
  if (hasAny(text, ["pleerni yop", "videoni yop", "pleerdan chiq", "close player"])) {
    return { action: 'close_player' }
  }

  // 9. Playback Speed
  const speedMatch = text.match(/tezlik\w*\s*(\d+(?:[.,]\d+)?)/)
  if (speedMatch) {
    return { action: 'set_speed', params: { speed: Number.parseFloat(speedMatch[1].replace(',', '.')) } }
  }
  if (hasAny(text, ['tezroq o\'ynat', 'tezlashtir', '1.5x', '2x'])) {
    return { action: 'set_speed', params: { speed: 1.5 } }
  }
  if (hasAny(text, ['sekinroq o\'ynat', 'sekinlashtir', '0.75x', '0.5x'])) {
    return { action: 'set_speed', params: { speed: 0.75 } }
  }
  if (hasAny(text, ['odatdagi tezlik', 'normal tezlik', '1x', 'asl tezlik'])) {
    return { action: 'set_speed', params: { speed: 1 } }
  }

  // 10. Episode navigation
  if (hasAny(text, ['keyingi qism', 'keyingi epizod', 'next episode', 'keyingisiga o\'t', 'keyingisi'])) {
    return { action: 'next_episode' }
  }
  if (hasAny(text, ['oldingi qism', 'oldingi epizod', 'previous episode', 'avvalgi qism', 'oldindagisi'])) {
    return { action: 'previous_episode' }
  }

  // 11. Captions / Subtitles
  if (hasAny(text, ['subtitrni yoq', 'subtitr yoq', 'matnni yoq', 'captions on'])) {
    return { action: 'enable_captions' }
  }
  if (hasAny(text, ['subtitrni o\'chir', 'subtitr ochir', 'captions off'])) {
    return { action: 'disable_captions' }
  }

  // 12. Page Scrolling
  if (hasAny(text, ['eng pastga', 'pastgacha tush', 'oxiriga tush', 'scroll to bottom'])) {
    return { action: 'scroll_to_bottom' }
  }
  if (hasAny(text, ['eng tepaga', 'yuqorigacha chiq', 'boshiga chiq', 'scroll to top'])) {
    return { action: 'scroll_to_top' }
  }
  if (hasAny(text, ['pastga tush', 'pastga sur', 'quyiga tush', 'scroll down', 'pastga'])) {
    return { action: 'scroll_down' }
  }
  if (hasAny(text, ['yuqoriga chiq', 'tepaga chiq', 'tepaga sur', 'scroll up', 'yuqoriga'])) {
    return { action: 'scroll_up' }
  }

  // 13. App Navigation
  if (hasAny(text, ['bosh sahifaga', 'bosh sahifa', 'asosiy', 'asosiy sahifa', 'uyga', 'home', 'главная'])) {
    return { action: 'go_home' }
  }
  if (hasAny(text, ['filmlarga o\'t', 'filmlar', 'filmlar sahifasi', 'kinolar sahifasi', 'kinolarni och', 'movies', 'фильмы'])) {
    return { action: 'open_movies_page' }
  }
  if (hasAny(text, ['seriallarga o\'t', 'seriallar', 'seriallar sahifasi', 'seriallarni och', 'series', 'сериалы'])) {
    return { action: 'open_series_page' }
  }
  if (hasAny(text, ['sevimlilarga o\'t', 'sevimlilar', 'mening ro\'yxatim', 'my list', 'saqlanganlar', 'favorites', 'избранное'])) {
    return { action: 'open_favorites_page' }
  }
  if (hasAny(text, ['tarixga o\'t', 'tomosha tarixi', 'history'])) {
    return { action: 'open_history_page' }
  }
  if (hasAny(text, ['profilimga o\'t', 'profil', 'mening profilim', 'profilni och', 'kabinet', 'profile', 'профиль'])) {
    return { action: 'open_profile_page' }
  }
  if (hasAny(text, ['sozlamalarga o\'t', 'sozlamalar', 'sozlamalarni och', 'settings', 'настройки'])) {
    return { action: 'open_settings_page' }
  }
  if ((text === 'orqaga qayt' || hasAny(text, ['ortga qayt', 'sahifadan chiq', 'orqaga'])) && !hasAny(text, ['soniya', 'daqiqa', 'sekund'])) {
    return { action: 'go_back' }
  }
  if (hasAny(text, ['sahifani yangila', 'qayta yukla', 'refresh'])) {
    return { action: 'refresh_page' }
  }

  return null
}
