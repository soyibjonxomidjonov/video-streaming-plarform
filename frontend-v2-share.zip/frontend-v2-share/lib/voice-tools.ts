import React from 'react'

export type PlayerBridge = {
  videoRef: React.RefObject<HTMLVideoElement | null>
  contentType: 'movie' | 'series'
  contentId: string | number
  contentTitle: string
  hasNextEpisode?: () => boolean
  hasPreviousEpisode?: () => boolean
  nextEpisode?: () => void
  previousEpisode?: () => void
  toggleFavorite?: () => void
  rate?: (stars: number) => void
  addComment?: (text: string) => Promise<void> | void
}

// Destructive tools that require explicit user confirmation before execution
export const DESTRUCTIVE_TOOLS = new Set([
  'logout',
  'remove_from_favorites',
  'remove_favorite',
  'clear_watch_history',
  'clear_history',
  'delete_comment',
  'remove_from_continue_watching',
])

export function getConfirmationPrompt(tool: string, params?: Record<string, any>): string {
  switch (tool) {
    case 'logout':
      return "Haqiqatan ham akkauntingizdan chiqmoqchimisiz?"
    case 'clear_watch_history':
    case 'clear_history':
      return "Barcha tomosha tarixini o'chirib tashlashni tasdiqlaysizmi?"
    case 'delete_comment':
      return "Izohni o'chirmoqchimisiz?"
    case 'remove_from_favorites':
    case 'remove_favorite':
      return params?.title
        ? `"${params.title}" filmini sevimlilardan o'chirmoqchimisiz?`
        : "Ushbu kontentni sevimlilardan o'chirmoqchimisiz?"
    case 'remove_from_continue_watching':
      return "Ushbu kontentni davom etayotganlar ro'yxatidan o'chirmoqchimisiz?"
    default:
      return "Ushbu amalni bajarishni tasdiqlaysizmi?"
  }
}

export type VoiceToolResult = { ok: boolean; message?: string }
