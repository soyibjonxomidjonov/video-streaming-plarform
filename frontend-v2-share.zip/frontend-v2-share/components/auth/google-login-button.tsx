'use client'

import React, { useState } from 'react'
import { GoogleLogin, CredentialResponse } from '@react-oauth/google'
import { useRouter } from 'next/navigation'
import { Loader2 } from 'lucide-react'
import { setToken, setRefreshToken } from '@/lib/api'
import { useAuth } from '@/components/auth-provider'

export function GoogleLoginButton() {
  const router = useRouter()
  const { refresh } = useAuth()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSuccess = async (credentialResponse: CredentialResponse) => {
    if (!credentialResponse.credential) {
      setError("Google token olinmadi")
      return
    }

    try {
      setLoading(true)
      setError(null)

      const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'https://backend.scholarmap.uz'
      
      // Backend Swagger: POST /v1/auth/google/login/ or POST /v1/auth/google/
      let response = await fetch(`${apiUrl}/v1/auth/google/login/`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id_token: credentialResponse.credential }),
      })

      if (!response.ok && response.status === 404) {
        // Fallback to /v1/auth/google/
        response = await fetch(`${apiUrl}/v1/auth/google/`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id_token: credentialResponse.credential }),
        })
      }

      if (!response.ok) {
        throw new Error("Serverda Google autentifikatsiya xatosi yuz berdi")
      }

      const data = await response.json()
      
      // Access va Refresh tokenlarni saqlash
      if (data.access) {
        setToken(data.access)
        if (data.refresh) {
          setRefreshToken(data.refresh)
        }
        await refresh()
        window.location.href = "/"
      } else if (data.token) {
        setToken(data.token)
        await refresh()
        window.location.href = "/"
      } else {
        throw new Error("Token olinmadi")
      }
    } catch (err: any) {
      setError(err.message || "Tizimga kirishda xatolik yuz berdi")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="w-full flex flex-col items-center gap-2">
      {loading ? (
        <div className="w-full py-3 flex items-center justify-center gap-2 rounded-2xl bg-[#101514] border border-[#00e599]/30 text-[#00e599] shadow-[0_0_15px_rgba(0,229,153,0.2)]">
          <Loader2 className="w-5 h-5 animate-spin" />
          <span className="text-xs font-bold">Google orqali tasdiqlanmoqda...</span>
        </div>
      ) : (
        <div className="w-full flex justify-center custom-google-btn overflow-hidden rounded-full border border-[rgba(0,229,153,0.2)] bg-[#101514] p-1 transition hover:border-[#00e599] hover:shadow-[0_0_15px_rgba(0,229,153,0.25)]">
          <GoogleLogin
            onSuccess={handleSuccess}
            onError={() => setError("Google orqali kirish bekor qilindi")}
            theme="filled_black"
            shape="pill"
            size="large"
            text="signin_with"
            width="100%"
          />
        </div>
      )}

      {error && (
        <p className="text-xs font-bold text-[#ff4d6d] mt-1 text-center">{error}</p>
      )}
    </div>
  )
}

export default GoogleLoginButton
