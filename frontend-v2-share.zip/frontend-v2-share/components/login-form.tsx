'use client'

import { type FormEvent, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { ArrowRight, Mail, KeyRound, Loader2 } from 'lucide-react'
import { api, ApiError, setToken, setRefreshToken } from '@/lib/api'
import { useAuth } from '@/components/auth-provider'
import GoogleSignInButton from '@/components/google-sign-in-button'
import { Logo } from '@/components/ui/logo'

export default function LoginForm({ googleClientId }: { googleClientId?: string }) {
  const router = useRouter()
  const { refresh } = useAuth()
  const [email, setEmail] = useState('')
  const [code, setCode] = useState('')
  const [step, setStep] = useState<'email' | 'code'>('email')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [info, setInfo] = useState('')

  const activeClientId =
    googleClientId ||
    process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID ||
    '106374320593-u4o15ahs5g3t798kvl6c4e6vte9lnn5s.apps.googleusercontent.com'

  const sendCode = async (e: FormEvent) => {
    e.preventDefault()
    const trimmed = email.trim().toLowerCase()
    if (!trimmed) return
    setLoading(true)
    setError('')
    try {
      await api.login(trimmed)
      setStep('code')
      setInfo(`${trimmed} manziliga 6 xonali tasdiqlash kodi yuborildi`)
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Xatolik yuz berdi. Qaytadan urining.')
    } finally {
      setLoading(false)
    }
  }

  const verifyCode = async (e: FormEvent) => {
    e.preventDefault()
    if (code.length < 6) return
    setLoading(true)
    setError('')
    try {
      const result = await api.verifyCode(email.trim().toLowerCase(), code)
      setToken(result.access)
      setRefreshToken(result.refresh)
      await refresh()
      router.replace('/')
    } catch (err) {
      if (err instanceof ApiError && err.status === 400) {
        setError("Noto'g'ri tasdiqlash kodi. Tekshirib qaytadan kiriting.")
      } else {
        setError('Xatolik yuz berdi. Qaytadan urining.')
      }
    } finally {
      setLoading(false)
    }
  }

  const resendCode = async () => {
    setLoading(true)
    setError('')
    try {
      await api.login(email.trim().toLowerCase())
      setInfo('Yangi kod emailingizga yuborildi.')
    } catch {
      setError("Kodni qayta yuborib bo'lmadi.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center p-4 bg-[#070A0C]">
      {/* Background glow */}
      <div
        className="pointer-events-none fixed inset-0"
        style={{
          background:
            'radial-gradient(ellipse 65% 45% at 50% 0%, rgba(0,255,163,0.1) 0%, transparent 70%)',
        }}
        aria-hidden
      />

      <div className="relative w-full max-w-md">
        {/* Brand Header */}
        <div className="mb-8 flex flex-col items-center gap-3">
          <Link href="/" className="group" aria-label="Bosh sahifa">
            <Logo className="size-14" />
          </Link>
          <div className="text-center">
            <h1 className="font-display text-2xl font-black tracking-tight text-[#F8FAFC]">
              S<span className="text-[#00FFA3]">-</span>M STREAM
            </h1>
            <p className="mt-1 text-xs text-[#64748B]">Video striming va AI ovozli platforma</p>
          </div>
        </div>

        {/* Card */}
        <div className="w-full min-w-0 rounded-2xl border border-[rgba(0,255,163,0.2)] bg-[#0F171A]/90 p-6 sm:p-8 shadow-[0_0_50px_rgba(0,0,0,0.8)] backdrop-blur-xl">
          {step === 'email' ? (
            <>
              <div className="mb-5 flex size-11 items-center justify-center rounded-xl bg-[rgba(0,255,163,0.1)] text-[#00FFA3]">
                <Mail size={20} />
              </div>
              <h2 className="font-display text-xl font-bold text-[#F8FAFC]">Tizimga kirish</h2>
              <p className="mt-1 text-sm text-[#64748B]">
                Emailingizga 6 xonali tasdiqlash kodi yuboriladi
              </p>

              {/* Google Sign In */}
              <div className="mt-5 mb-1 min-h-[44px]">
                <GoogleSignInButton clientId={activeClientId} onError={setError} />
                <div className="my-5 flex items-center gap-3">
                  <div className="h-px flex-1 bg-[rgba(0,255,163,0.12)]" />
                  <span className="text-xs text-[#64748B]">yoki email orqali</span>
                  <div className="h-px flex-1 bg-[rgba(0,255,163,0.12)]" />
                </div>
              </div>

              <form id="login-email-form" onSubmit={sendCode} className="flex flex-col gap-4">
                <div>
                  <label htmlFor="email-input" className="mb-1.5 block text-xs font-semibold text-[#94A3B8] uppercase tracking-wide">
                    Email manzili
                  </label>
                  <div className="flex items-center gap-3 rounded-xl border border-[rgba(0,255,163,0.18)] bg-[#0B1013] px-4 py-3.5 transition focus-within:border-[#00FFA3] focus-within:shadow-[0_0_12px_rgba(0,255,163,0.15)] min-h-[50px]">
                    <Mail size={15} className="shrink-0 text-[#64748B]" />
                    <input
                      id="email-input"
                      type="email"
                      inputMode="email"
                      autoComplete="email"
                      autoFocus
                      value={email}
                      onChange={(e) => { setEmail(e.target.value); setError('') }}
                      placeholder="sizning@email.com"
                      className="min-w-0 w-full bg-transparent text-sm text-[#F8FAFC] outline-none placeholder:text-[#64748B] border-none shadow-none ring-0 focus:ring-0"
                      required
                      disabled={loading}
                    />
                  </div>
                </div>

                {error && (
                  <p className="rounded-xl border border-[#EF4444]/30 bg-[#EF4444]/08 px-4 py-2.5 text-xs font-medium text-[#EF4444]">
                    {error}
                  </p>
                )}

                <button
                  id="send-code-btn"
                  type="submit"
                  disabled={loading || !email.trim()}
                  className="flex min-h-[50px] items-center justify-center gap-2 rounded-xl bg-[#00FFA3] py-3.5 text-sm font-bold text-[#070A0C] shadow-[0_0_20px_rgba(0,255,163,0.35)] transition hover:bg-[#1AFFA8] hover:shadow-[0_0_28px_rgba(0,255,163,0.5)] active:scale-95 disabled:opacity-50"
                >
                  {loading ? (
                    <Loader2 size={16} className="animate-spin" />
                  ) : (
                    <>Kodni yuborish <ArrowRight size={15} /></>
                  )}
                </button>
              </form>

              <p className="mt-5 text-center text-xs text-[#64748B]">
                Akkauntingiz yo&apos;qmi?{' '}
                <Link href="/register" className="font-bold text-[#00FFA3] hover:underline">
                  Ro&apos;yxatdan o&apos;tish
                </Link>
              </p>
            </>
          ) : (
            /* STEP 2: CODE VERIFICATION */
            <>
              <div className="mb-5 flex size-11 items-center justify-center rounded-xl bg-[rgba(0,255,163,0.1)] text-[#00FFA3]">
                <KeyRound size={20} />
              </div>
              <h2 className="font-display text-xl font-bold text-[#F8FAFC]">Kodni tasdiqlash</h2>
              <p className="mt-1 text-sm text-[#64748B]">{info}</p>

              <form id="login-code-form" onSubmit={verifyCode} className="mt-5 flex flex-col gap-4">
                <div>
                  <label htmlFor="code-input" className="mb-1.5 block text-xs font-semibold text-[#94A3B8] uppercase tracking-wide">
                    6 xonali tasdiqlash kodi
                  </label>
                  <input
                    id="code-input"
                    type="text"
                    inputMode="numeric"
                    maxLength={6}
                    autoFocus
                    value={code}
                    onChange={(e) => { setCode(e.target.value.replace(/\D/g, '')); setError('') }}
                    placeholder="123456"
                    className="w-full min-w-0 rounded-xl border border-[rgba(0,255,163,0.2)] bg-[#0B1013] px-4 py-4 text-center font-display text-2xl font-black tracking-widest text-[#00FFA3] outline-none transition focus:border-[#00FFA3] focus:shadow-[0_0_12px_rgba(0,255,163,0.2)] min-h-[60px]"
                    required
                    disabled={loading}
                  />
                </div>

                {error && (
                  <p className="rounded-xl border border-[#EF4444]/30 bg-[#EF4444]/08 px-4 py-2.5 text-xs font-medium text-[#EF4444]">
                    {error}
                  </p>
                )}

                <button
                  id="verify-code-btn"
                  type="submit"
                  disabled={loading || code.length < 6}
                  className="flex min-h-[50px] items-center justify-center gap-2 rounded-xl bg-[#00FFA3] py-3.5 text-sm font-bold text-[#070A0C] shadow-[0_0_20px_rgba(0,255,163,0.35)] transition hover:bg-[#1AFFA8] active:scale-95 disabled:opacity-50"
                >
                  {loading ? <Loader2 size={16} className="animate-spin" /> : 'Tasdiqlash va Kirish'}
                </button>

                <div className="flex items-center justify-between text-xs text-[#64748B]">
                  <button
                    type="button"
                    onClick={() => { setStep('email'); setCode(''); setError('') }}
                    className="transition hover:text-[#F8FAFC] min-h-[44px] px-1"
                  >
                    ← Emailni o&apos;zgartirish
                  </button>
                  <button
                    type="button"
                    onClick={resendCode}
                    disabled={loading}
                    className="font-bold text-[#00FFA3] transition hover:underline min-h-[44px] px-1"
                  >
                    Kodni qayta yuborish
                  </button>
                </div>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
