// Local (client-side) fast-path matcher for Uzbek voice commands.
// Only covers non-destructive, low-latency actions (playback, volume, navigation,
// scrolling, episode switching). Everything else (search, favorites, ratings,
// comments, logout, anything ambiguous) is left for the backend agent to resolve.

export type LocalCommand = {
  action: string
  params?: { seconds?: number; value?: number; speed?: number; query?: string }
}

function normalize(raw: string) {
  return raw
    .toLowerCase()
    .replace(/[’ʻʼ`´]/g, "'")
    .replace(/[.,!?;:]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
}

function hasAny(text: string, words: string[]) {
  return words.some(word => text.includes(word))
}

// Simple negation guard: "to'xtatma" (don't stop), "o'ynatma" (don't play) etc.
// If the matched verb stem is immediately followed by a negation suffix, bail out
// and let the backend interpret intent instead of risking the wrong action.
function isNegated(text: string, stems: string[]) {
  return stems.some(stem => text.includes(`${stem}ma`) || text.includes(`${stem}mang`))
}

function firstNumber(text: string): number | null {
  const match = text.match(/(\d+(?:[.,]\d+)?)/)
  if (!match) return null
  return Number.parseFloat(match[1].replace(',', '.'))
}

export function matchLocalCommand(transcriptRaw: string): LocalCommand | null {
  const text = normalize(transcriptRaw)
  if (!text) return null

  // Assistant control
  if (hasAny(text, ['yordamchini o\'chir', 'ovozli boshqaruvni o\'chir', 'mikrofonni o\'chir', 'tinglashni to\'xtat'])) {
    return { action: 'stop_listening' }
  }

  // Play / Pause
  const pauseStems = ["to'xtat", 'pauza qil']
  if (!isNegated(text, pauseStems) && hasAny(text, ['pauza', "to'xtat", 'toxtat', 'kutib tur'])) {
    // Disambiguate from seek-backward ("orqaga ... soniya")
    if (!hasAny(text, ['orqaga', 'soniya', 'daqiqa'])) return { action: 'pause_video' }
  }
  const playStems = ["o'ynat", 'boshla']
  if (!isNegated(text, playStems) && hasAny(text, ["o'ynat", 'oynat', 'ijro et', 'davom et', 'davom ettir', 'play'])) {
    return { action: 'play_video' }
  }

  // Seek forward / backward
  if (hasAny(text, ['oldinga', 'forward'])) {
    const seconds = firstNumber(text)
    return { action: 'seek_forward', params: { seconds: seconds ?? 10 } }
  }
  if (hasAny(text, ['orqaga', 'backward']) && hasAny(text, ['soniya', 'sekund', 'daqiqa', 'minute', 'sek'])) {
    const rawSeconds = firstNumber(text)
    const seconds = hasAny(text, ['daqiqa', 'minute']) ? (rawSeconds ?? 1) * 60 : rawSeconds ?? 10
    return { action: 'seek_backward', params: { seconds } }
  }
  if (text === 'orqaga' || hasAny(text, ['bir oz orqaga', 'ozgina orqaga'])) {
    return { action: 'seek_backward', params: { seconds: 10 } }
  }

  // Absolute seek: "3 daqiqaga o't", "2:30 ga o't"
  const timeMatch = text.match(/(\d+)\s*:\s*(\d+)/)
  if (timeMatch && hasAny(text, ["o't", 'otish', "o'tkaz"])) {
    const seconds = Number.parseInt(timeMatch[1], 10) * 60 + Number.parseInt(timeMatch[2], 10)
    return { action: 'seek_to_time', params: { seconds } }
  }
  if (hasAny(text, ['daqiqaga', 'daqiqadan']) && hasAny(text, ["o't", "o'tkaz"])) {
    const minutes = firstNumber(text) ?? 0
    return { action: 'seek_to_time', params: { seconds: minutes * 60 } }
  }

  // Volume
  if (hasAny(text, ['ovozni ochir', "ovozni o'chir", 'jim qil', 'mute'])) {
    return { action: 'mute' }
  }
  if (hasAny(text, ['ovozni yoq', 'ovozni qayt', 'unmute', 'jimlikni ochir']) && !hasAny(text, ['past', 'baland'])) {
    return { action: 'unmute' }
  }
  const volumeMatch = text.match(/ovoz\w*\s*(\d+)\s*(foiz|%)?/)
  if (volumeMatch) {
    const value = Number.parseInt(volumeMatch[1], 10)
    return { action: 'set_volume', params: { value: Math.max(0, Math.min(100, value)) } }
  }
  if (hasAny(text, ['ovozni baland', 'ovozni kotar', "ovozni ko'tar", 'balandroq']) ) {
    return { action: 'increase_volume' }
  }
  if (hasAny(text, ['ovozni past', 'ovozni tushir', 'pastroq'])) {
    return { action: 'decrease_volume' }
  }

  // Fullscreen
  if (hasAny(text, ["to'liq ekran", 'toliq ekran', 'fullscreen', 'butun ekran'])) {
    return { action: 'toggle_fullscreen' }
  }
  if (hasAny(text, ['ekrandan chiq', 'kichraytir'])) {
    return { action: 'exit_fullscreen' }
  }

  // Playback speed
  const speedMatch = text.match(/tezlik\w*\s*(\d+(?:[.,]\d+)?)/)
  if (speedMatch) {
    return { action: 'set_speed', params: { speed: Number.parseFloat(speedMatch[1].replace(',', '.')) } }
  }
  if (hasAny(text, ['tezroq', 'tezlashtir'])) return { action: 'set_speed', params: { speed: 1.5 } }
  if (hasAny(text, ['sekinroq', 'sekinlashtir'])) return { action: 'set_speed', params: { speed: 0.75 } }
  if (hasAny(text, ['odatdagi tezlik', 'normal tezlik'])) return { action: 'set_speed', params: { speed: 1 } }

  // Episode navigation
  if (hasAny(text, ['keyingi qism', 'keyingi epizod', 'next episode', 'keyingisiga'])) {
    return { action: 'next_episode' }
  }
  if (hasAny(text, ['oldingi qism', 'oldingi epizod', 'previous episode', 'avvalgisiga'])) {
    return { action: 'previous_episode' }
  }

  // Scrolling
  if (hasAny(text, ['pastga tush', 'pastga o\'t', 'quyiga tush', 'scroll down'])) {
    return { action: 'scroll_down' }
  }
  if (hasAny(text, ['yuqoriga chiq', 'tepaga chiq', 'yuqoriga o\'t', 'scroll up'])) {
    return { action: 'scroll_up' }
  }

  // Page navigation (non-destructive)
  if (hasAny(text, ['bosh sahifaga', 'bosh sahifa', 'go home'])) {
    return { action: 'go_home' }
  }
  if ((text === 'orqaga qayt' || hasAny(text, ['ortga qayt', 'sahifadan chiq'])) && !hasAny(text, ['soniya', 'daqiqa'])) {
    return { action: 'go_back' }
  }
  if (hasAny(text, ['sahifani yangila', 'refresh'])) {
    return { action: 'refresh_page' }
  }
  // Search (fallback to local if agent fails)
  if (hasAny(text, ['kino top', 'serial top', 'qidir', 'topib', 'izla', 'top'])) {
    let query = text
      .replace(/menga/g, '')
      .replace(/kino/g, '')
      .replace(/serial/g, '')
      .replace(/topib ber/g, '')
      .replace(/topib/g, '')
      .replace(/qidir/g, '')
      .replace(/izla/g, '')
      .replace(/top/g, '')
      .replace(/iltimos/g, '')
      .replace(/jamiyatlarga/g, '') // as transcribed in error
      .trim()
    return { action: 'search_content', params: { query } }
  }

  return null
}
