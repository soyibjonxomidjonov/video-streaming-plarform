const DEFAULT_API_URL = 'https://backend.scholarmap.uz'
const DEFAULT_STREAMER_HEALTH_URL = 'https://backend.scholarmap.uz/health'

function normalizeBaseUrl(value: string) {
  return value.replace(/\/+$/, '')
}

export const API_BASE = normalizeBaseUrl(process.env.NEXT_PUBLIC_API_URL?.trim() || DEFAULT_API_URL)
export const STREAMER_HEALTH = normalizeBaseUrl(process.env.NEXT_PUBLIC_STREAMER_HEALTH?.trim() || DEFAULT_STREAMER_HEALTH_URL)

// In the browser, JSON requests go through the Next.js rewrite proxy
// (see next.config.mjs) to avoid backend CORS errors. On the server
// (SSR/RSC), we call the backend directly — no browser, no CORS.
const REQUEST_BASE = typeof window === 'undefined' ? API_BASE : '/api-proxy'

export function getGoogleAuthUrl() {
  return process.env.NEXT_PUBLIC_GOOGLE_AUTH_URL?.trim() || `${API_BASE}/v1/auth/google/`
}

export function getAiWebSocketUrl() {
  const configured = process.env.NEXT_PUBLIC_AI_WS_URL?.trim()
  if (configured) return configured
  const url = new URL(API_BASE)
  url.protocol = url.protocol === 'https:' ? 'wss:' : 'ws:'
  url.pathname = '/ws/agent/test/'
  url.search = ''
  return url.toString()
}

export function getVoiceWebSocketUrl(sessionId = 'web') {
  const configured = process.env.NEXT_PUBLIC_VOICE_WS_URL?.trim()
  if (configured) return configured.replace('{session_id}', encodeURIComponent(sessionId))
  const url = new URL(API_BASE)
  url.protocol = url.protocol === 'https:' ? 'wss:' : 'ws:'
  url.pathname = `/ws/agent/${encodeURIComponent(sessionId)}/`
  url.search = ''
  return url.toString()
}

export type Genre = { id: number; name: string }

export type MediaItem = {
  id: number
  title?: string
  name?: string
  description?: string
  overview?: string
  poster?: string
  poster_url?: string
  image?: string
  backdrop?: string
  backdrop_url?: string
  year?: number | string
  release_year?: number | string
  rating?: number | string
  average_rating?: number | string
  duration?: number | string
  genre?: string | Genre[]
  genres?: Genre[]
  episodes?: Episode[]
  seasons?: Season[]
}

export type Episode = {
  id: number
  title?: string
  name?: string
  episode_number?: number
  season_number?: number
  duration?: number | string
  poster?: string
  poster_url?: string
}

export type Season = {
  id: number
  season_number?: number
  name?: string
  episodes?: Episode[]
}

export type Comment = {
  id: number
  text?: string
  content?: string
  user?: string | { username?: string; email?: string }
  username?: string
  created_at?: string
}

export type UserProfile = {
  id?: number
  email?: string
  username?: string
  first_name?: string
  last_name?: string
  age?: number | string
  is_staff?: boolean
  is_superuser?: boolean
  role?: string
}

export type ApiList<T> = T[] | { results: T[]; count?: number; next?: string | null; previous?: string | null }

export class ApiError extends Error {
  status: number
  constructor(message: string, status: number) {
    super(message)
    this.status = status
  }
}

const TOKEN_KEY = 'streamora_token'

export function getToken(): string | null {
  if (typeof window === 'undefined') return null
  try {
    return window.localStorage.getItem(TOKEN_KEY)
  } catch {
    return null
  }
}

export function setToken(token: string | null) {
  if (typeof window === 'undefined') return
  try {
    if (token) window.localStorage.setItem(TOKEN_KEY, token)
    else window.localStorage.removeItem(TOKEN_KEY)
  } catch {
    /* ignore storage errors */
  }
}

export function mediaTitle(item: MediaItem | Episode) {
  return item.title ?? item.name ?? 'Untitled'
}

export function mediaDescription(item: MediaItem) {
  return item.description ?? item.overview ?? ''
}

export function mediaImage(item: MediaItem, kind: 'poster' | 'backdrop' = 'poster') {
  const poster = item.poster_url ?? item.poster ?? item.image ?? ''
  const backdrop = item.backdrop_url ?? item.backdrop ?? ''
  return kind === 'backdrop' ? backdrop || poster : poster || backdrop
}

export function mediaRating(item: MediaItem) {
  const value = item.rating ?? item.average_rating
  const num = typeof value === 'string' ? Number.parseFloat(value) : value
  return typeof num === 'number' && !Number.isNaN(num) ? num : null
}

export function mediaYear(item: MediaItem) {
  return item.year ?? item.release_year ?? null
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), 5000)
  const token = getToken()
  const isGet = !init?.method || init.method === 'GET'
  try {
    const response = await fetch(`${REQUEST_BASE}${path}`, {
      ...init,
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        ...(init?.headers ?? {}),
      },
      credentials: 'include',
      cache: isGet && !token ? 'force-cache' : 'no-store',
      signal: controller.signal,
    })
    if (!response.ok) {
      let detail = `API request failed: ${response.status}`
      try {
        const body = await response.json()
        detail = body.detail ?? body.message ?? detail
      } catch {
        /* non-json error */
      }
      throw new ApiError(detail, response.status)
    }
    if (response.status === 204) return undefined as T
    const text = await response.text()
    return (text ? JSON.parse(text) : undefined) as T
  } finally {
    clearTimeout(timeout)
  }
}

export const api = {
  movies: (params = '') => request<ApiList<MediaItem>>(`/v1/movie/${params ? `?${params}` : ''}`),
  movie: (id: string | number) => request<MediaItem>(`/v1/movie/${id}/`),
  series: (params = '') => request<ApiList<MediaItem>>(`/v1/series/${params ? `?${params}` : ''}`),
  serie: (id: string | number) => request<MediaItem>(`/v1/series/${id}/`),
  episode: (id: string | number) => request<Episode>(`/v1/episode/${id}/`),
  seriesEpisodes: (seriesId: string | number) => request<ApiList<Episode>>(`/v1/episode/?series=${seriesId}`),
  genres: () => request<ApiList<Genre>>('/v1/genre/'),
  search: (query: string) => request<ApiList<MediaItem>>(`/v1/embedding_search/?search=${encodeURIComponent(query)}`),
  movieComments: (movieId: string | number) => request<ApiList<Comment>>(`/v1/movie-comments/?movie=${movieId}`),
  seriesComments: (seriesId: string | number) => request<ApiList<Comment>>(`/v1/series-comments/?series=${seriesId}`),
  movieStream: (id: string | number) => `${API_BASE}/v1/movie/${id}/stream/`,
  episodeStream: (id: string | number) => `${API_BASE}/v1/episode/${id}/stream/`,

  me: () => request<UserProfile>('/v1/auth/me/'),
  user: (id: number | string) => request<UserProfile>(`/v1/users/${id}/`),
  updateUser: (id: number | string, data: Partial<UserProfile>) => request<UserProfile>(`/v1/users/${id}/`, { method: 'PATCH', body: JSON.stringify(data) }),
  login: (email: string) => request('/v1/auth/login/', { method: 'POST', body: JSON.stringify({ email }) }),
  register: (payload: { email: string; username?: string; first_name?: string; last_name?: string; age?: string | number }) => request('/v1/auth/register/', { method: 'POST', body: JSON.stringify(payload) }),
  verifyCode: (email: string, code: string) => request<{ token?: string; access?: string; key?: string }>('/v1/auth/code/verify/', { method: 'POST', body: JSON.stringify({ email, verify_code: code }) }),

  favorites: () => request<ApiList<MediaItem>>('/v1/movie-favourite/'),
  history: () => request<ApiList<{ movie?: MediaItem; series?: MediaItem; progress?: number; duration?: number }>>('/v1/movie-watchprogress/'),

  favoriteMovie: (movieId: number) => request('/v1/movie-favourite/', { method: 'POST', body: JSON.stringify({ movie: movieId }) }),
  rateMovie: (movieId: number, rating: number) => request('/v1/movie-rating/', { method: 'POST', body: JSON.stringify({ movie: movieId, stars: rating }) }),
  commentMovie: (movieId: number, text: string) => request<Comment>('/v1/movie-comments/', { method: 'POST', body: JSON.stringify({ movie: movieId, text }) }),
  favoriteSeries: (seriesId: number) => request('/v1/series-favourite/', { method: 'POST', body: JSON.stringify({ series: seriesId }) }),
  rateSeries: (seriesId: number, rating: number) => request('/v1/series-rating/', { method: 'POST', body: JSON.stringify({ series: seriesId, stars: rating }) }),
  commentSeries: (seriesId: number, text: string) => request<Comment>('/v1/series-comments/', { method: 'POST', body: JSON.stringify({ series: seriesId, text }) }),
  progressMovie: (movieId: number, seconds: number) => request('/v1/movie-watchprogress/', { method: 'POST', body: JSON.stringify({ movie: movieId, position_seconds: Math.floor(seconds) }) }),
  progressEpisode: (episodeId: number, seconds: number) => request('/v1/series-watchprogress/', { method: 'POST', body: JSON.stringify({ episode: episodeId, position_seconds: Math.floor(seconds) }) }),

  createGenre: (name: string) => request<Genre>('/v1/genre/', { method: 'POST', body: JSON.stringify({ name }) }),
  deleteMovie: (movieId: number) => request(`/v1/movie/${movieId}/`, { method: 'DELETE' }),
  deleteSeries: (seriesId: number) => request(`/v1/series/${seriesId}/`, { method: 'DELETE' }),
}

export function unwrapList<T>(data: ApiList<T> | undefined | null): T[] {
  if (!data) return []
  return Array.isArray(data) ? data : Array.isArray(data.results) ? data.results : []
}

export function commentAuthor(comment: Comment) {
  if (typeof comment.user === 'string') return comment.user
  return comment.user?.username ?? comment.user?.email ?? comment.username ?? 'Anonymous'
}

export function commentText(comment: Comment) {
  return comment.text ?? comment.content ?? ''
}
